<?php
session_start(); // Start the session
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <title>Simple Notes</title>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://unpkg.com/leaflet@1.9.3/dist/leaflet.css" integrity="sha256-kLaT2GOSpHechhsozzB+flnD+zUyjE2LlfWPgU04xyI=" crossorigin="" />
    <link href="https://unpkg.com/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
    <link rel="stylesheet" href="/css/output.css">
    <link rel="stylesheet" href="/css/styles.css">
    <link rel="stylesheet" href="/css/style2.css">
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>

    <style>
        /* Global Styling */
        /* Global Styling */
        body {
    font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
    background-color: #f8f9fa;
    margin: 0;
    padding: 0;
}

.container {
    max-width: 800px;
    margin: 30px auto;
    padding: 20px;
    background-color: #ffffff;
    box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
    border-radius: 10px;
    margin-top: 100px;
}

/* Card and Form Styling */
.card {
    border: none;
    background-color: #f8f9fa;
    box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
    margin-bottom: 20px;
    padding: 1em; /* Add padding for better content layout */
    box-sizing: border-box; /* Ensure padding is included in width calculation */
    overflow-wrap: break-word; /* Break long words to fit within the card */
}

.card-title {
    color: #343a40;
    font-size: 1.2em;
    margin-bottom: 15px;
}

.form-control {
    border: 1px solid #ced4da;
    border-radius: 5px;
    padding: 10px;
    font-size: 18px; /* Increased font size */
}

.btn-primary, .btn-secondary, .btn-danger {
    background-color: #082D0F;
    border: none;
    padding: 12px 30px;
    font-size: 1em;
    border-radius: 5px;
    color: #ffffff;
    cursor: pointer;
    transition: background-color 0.3s ease;
}

.btn-primary:hover, .btn-secondary:hover, .btn-danger:hover {
    background-color: #17B890;
}

.btn-primary:active, .btn-secondary:active, .btn-danger:active {
    background-color: #1e7e34;
}

.text-center {
    text-align: center;
    margin-bottom: 20px;
}

h2 {
    color: #343a40;
    font-size: 2em;
    font-weight: bold;
}

hr {
    border-color: #ced4da;
    margin: 30px 0;
}

#notes .card {
    margin-bottom: 15px;
    box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
}


.pet, .dash, .histo {
    position: fixed;
    top: 10px;
    padding: 10px 20px;
    text-decoration: none;
    color: #ffffff;
    background-color: #082D0F;
    border: 1px solid #28a745;
    border-radius: 5px;
    transition: background-color 0.3s, border-color 0.3s, color 0.3s;
}

.pet {
    left: 10px;
}

.dash {
    left: 190px;
   
}

.histo {
    left: 390px;
  
}

.pet:hover, .dash:hover, .histo:hover {
    background-color: #17B890;
    border-color: #218838;
}

.pet:active, .dash:active, .histo:active {
    background-color: #1e7e34;
    border-color: #1e7e34;
}

h2.font-medium.text-xs.md\:text-xl.text-center.text-teal-500 {
    margin-bottom: 0px !important;
}

#sidebar {
    width: 20%; 
    height: 100vh; 
    background-color: white; 
}

@media (max-width: 700px) {
    span {
        display: none;
    }

    #sidebar {
        width: 10%; 
        height: 100vh; 
        background-color: white; 
    }
}

    </style>
</head>

<body>

    <div class="grid grid-cols-5 h-screen">
        <div id="sidebar">
            <?php include('./sidebar-1.php'); ?>
        </div>
        <div class="col-span-4 h-full">
            <div class="grid grid-cols-1 md:grid-cols-2 gap-4 m-10 md:mt-48">
                <div class="container my-3">
                    <h2 class="text-center">Notes</h2>
                    <div class="card shadow-sm rounded-0">
                        <div class="card-body">
                            <h5 class="card-title">Create New Note</h5>
                            <div class="form-group">
                                <input type="hidden" name="key" value="">
                                <textarea id="addTxt" class="form-control rounded-0" rows="3"></textarea>
                            </div>
                            <div class="text-center flex justify-end gap-2">
                                <button id="addBtn" class="btn btn-primary rounded-0">Add Note</button>
                                <button id="cancelBtn" class="btn btn-secondary rounded-0 border">Cancel</button>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="container my-3">
                    <h2 class="text-center">Notes List</h2>
                    <div class="card shadow-sm rounded-0">
                        <div class="card-body">
                            <div id="notes" class="row container-fluid m-2">
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!----------JAVASCRIPT--------->
    <script src="./note/js/jquery.min.js"></script>
    <script src="./note/js/popper.min.js"></script>
    <script src="./note/js/bootstrap.min.js"></script>
    <script src="./note/js/app.js"></script>
</body>

</html>