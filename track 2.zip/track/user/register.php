<?php
include 'config.php';

$message = []; // Initialize an array to store messages

if(isset($_POST['submit'])) 
   // Escape user inputs for security
   $name = mysqli_real_escape_string($conn, $_POST['name']);
   $email = mysqli_real_escape_string($conn, $_POST['email']);
   $password = mysqli_real_escape_string($conn, $_POST['password']);
   $cpassword = mysqli_real_escape_string($conn, $_POST['cpassword']);

   // Validate if email already exists
   $query = "SELECT * FROM `user_form` WHERE email = '$email'";
   $result = mysqli_query($conn, $query);

   if(mysqli_num_rows($result) > 0) {
      $message[] = 'User already exists with this email address'; 
   } else {
      // Validate passwords match
      if($password != $cpassword) {
         $message[] = 'Confirm password does not match!';
      } else {
         // Hash the password (using md5 is not recommended for real applications)
         $hashed_password = md5($password);

         // Insert new user into database
         $insert_query = "INSERT INTO `user_form` (name, email, password) VALUES ('$name', '$email', '$hashed_password')";
         $insert_result = mysqli_query($conn, $insert_query);

         if($insert_result) {
            $message[] = 'Registered successfully!';
            header('location: login.php');
            exit();
         } else {
            $message[] = 'Registration failed: ' . mysqli_error($conn);
         }
      }
   }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
   <meta charset="UTF-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <title>Register</title>

   <!-- Custom CSS file link -->
   <link rel="stylesheet" href="css/style.css">
   <style>
      .btn {
         background: #17b890;
      }      
      @media (max-width: 768px) {
         p {
            font-size: smaller !important;
         }

         a {
            font-size: small;
         }

        }
   </style>
</head>
<body>
   
<div class="form-container">
   <form action="" method="post">
      <h3>Register Now</h3>
      <?php
      if(!empty($message)) {
         foreach($message as $msg) {
            echo '<div class="message">'.$msg.'</div>';
         }
      }
      ?>
      <input type="text" name="name" placeholder="Enter username" class="box" required>
      <input type="email" name="email" placeholder="Enter email" class="box" required>
      <input type="password" name="password" placeholder="Enter password" class="box" required>
      <input type="password" name="cpassword" placeholder="Confirm password" class="box" required>
      <input type="submit" name="submit" value="Register Now" class="btn">
      <p>Already have an account? <a href="login.php">Login Now</a></p>
   </form>
</div>

</body>
</html>
